$(function(){
    //菜单点击
    // 记录点击索引值，防火狐刷新
    var Index,nav;
    $(".J_menuItem").on('click',function(){
        var url = $(this).attr('data-href');
        $("#J_iframe").attr('src',url);
        window.localStorage.setItem("src",url);
        if ($(this).attr('data-toggle') == 'true') {
        	$('.layui-header .dropdown .dropdown-toggle').removeClass('active')
        	$('.layui-header .dropdown .dropdown-menu').stop(true,false).slideUp()
        }else{
        	Index = $(this).parents('li').index();
        	nav = $(this).parent().index();
        	window.localStorage.setItem("Index",Index);
        	window.localStorage.setItem("nav",nav);
        }
        return false;
    });


	$('.navbar-default ul li').eq(0).children('dl').stop(true,false).slideDown();
	$('.navbar-default ul li>a').click(function(){
		if ($(this).parent().hasClass('active')) {
			$(this).parent().removeClass('active');
			$(this).siblings().stop(true,false).slideUp();
		}else{
			$(this).parent().addClass('active');
			$(this).siblings().stop(true,false).slideDown();
			$(this).parent().siblings().removeClass('active');
			$(this).parent().siblings().children('dl').stop(true,false).slideUp();
		}
	})
	// 一级导航下拉
	$('.layui-header .dropdown .dropdown-toggle').click(function(){
		if ($(this).hasClass('active')) {
			$(this).siblings().stop(true,false).slideUp();
			$(this).removeClass('active')
		}else{
			$(this).siblings().stop(true,false).slideDown();
			$(this).addClass('active')
		}
	})

	// 菜单点击设置锚点记录当前iframe值
	$('.navbar-default ul li dl a').click(function(){
	  	$(this).parents().addClass('active');
	  	$(this).parents().siblings().removeClass('active');
	  	$(this).parents('li').siblings().find('dd').removeClass('active');
	})


	// 页面进入时获取刷新前的iframe值
	var newIndex = window.localStorage.getItem("Index");
	var newnav = window.localStorage.getItem("nav");
	var newsrc = window.localStorage.getItem("src");
	if (newsrc == '' || newsrc == null) {
		$("#J_iframe").attr('src','welcome.html');
	}else{
		$('.navbar-default ul li').eq(newIndex).addClass('active');
		$('.navbar-default ul li').eq(newIndex).children('dl').stop(true,false).slideDown()
		$('.navbar-default ul li').eq(newIndex).find('dd').eq(newnav).addClass('active');
		$('.navbar-default ul li').eq(newIndex).siblings().removeClass('active');
		$('.navbar-default ul li').eq(newIndex).find('dd').eq(newnav).siblings().removeClass('active');
		$('.navbar-default ul li').eq(newIndex).siblings().children('dl').stop(true,false).hide()
		$("#J_iframe").attr('src',newsrc);
	}
	// console.log(newsrc)
	
	// var indexurl = window.location.href;
	// // 判断页面是否为主页
	// if (indexurl.indexOf("#") != -1) {

	// 	var indexurl_length = indexurl.length;
	// 	var star = indexurl.indexOf("#")+1;
	// 	var iframeurl = indexurl.substring(star,indexurl_length);

	// 	// 判断页面是否存在时
	// 	var nopage = iframeurl.substring(0,iframeurl.indexOf("?"))
	// 	console.log(nopage)
	// 	if (nopage == 'undefined' || nopage == '') {
			
	// 		$('.navbar-default ul li').eq(0).addClass('active');
	// 		$('.navbar-default ul li').eq(0).find('dd').eq(0).addClass('active');
	// 		$("#J_iframe").attr('src','welcome.html');
	// 	} else {

	// 		$("#content-main>#J_iframe").attr('src',iframeurl);
	// 		// 页面进入时的导航
	// 		var Nav_id = iframeurl.substring(iframeurl.indexOf("&")-1,iframeurl.indexOf("&"));
	// 		var Nav_nav = iframeurl.substr(iframeurl.length-1,1)
	// 		$('.navbar-default ul li').eq(Nav_id).addClass('active');
	// 		$('.navbar-default ul li').eq(Nav_id).children('dl').stop(true,false).slideDown()
	// 		$('.navbar-default ul li').eq(Nav_id).find('dd').eq(Nav_nav).addClass('active');
	// 		$('.navbar-default ul li').eq(Nav_id).siblings().children('dl').stop(true,false).hide()
	// 		// 删除其他active
	// 		$('.navbar-default ul li').eq(Nav_id).siblings().removeClass('active');
	// 		$('.navbar-default ul li').eq(Nav_id).find('dd').eq(Nav_nav).siblings().removeClass('active');
	// 	}
	// } else {
	// 	$("#J_iframe").attr('src','welcome.html');
	// 	$('.navbar-default ul li').eq(0).addClass('active');
	// 	$('.navbar-default ul li').eq(0).find('dd').eq(0).addClass('active');
	// }
});
