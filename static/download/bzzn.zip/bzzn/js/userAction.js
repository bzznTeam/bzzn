$(function(){


		var WinW = $(window).width();
		var WinH = $(window).height();
		$('.main').css('min-height',WinH-120);
		var LeftH = $('.con .left').height();
		$('.con').css('min-height',LeftH);

		// 二级菜单
		$('.con .left .list .m_slide').click(function(){
			if ($(this).hasClass('on')) {
				$(this).removeClass('on');
				$(this).siblings('ul').slideUp()
			}else{
				$(this).addClass('on');
				$(this).siblings('ul').slideDown()
			}
		})

		$(window).resize(function(){
			WinW = $(window).width();
			WinH = $(window).height();
			$('.main').css('min-height',WinH-120);
			LeftH = $('.con .left').height();
			$('.con').css('min-height',LeftH)
		})
})