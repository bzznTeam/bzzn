$(function(){
	$('.recharge-header .message_li').click(function(){
        $.ajax({
            url:"../ajax/order-message_ajax.html",
            type:"post",
            dataType: "html",
            success:function(res){
                $('body').append(res);
               
            }
        })
    })
    // 关闭留言弹窗
    $(document).on('click','.order-message .tit .close',function(){
        $('.order-message').remove()
    })
})